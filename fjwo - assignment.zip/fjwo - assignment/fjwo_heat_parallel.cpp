#include <iostream>
#include <cmath>
#include <mpi.h>
using namespace std;

static const double PI = 3.1415926536; 

int main(int argc, char* argv[]){

int rank, size, ierr;
int M = 100;  // M length intervals
int N = 10000; // N time intervals
int nproc = 9;
int J = ((M-1)/nproc) + 2;
double T = 0.1;    // simulation time
double U[2][M+1];  // stores the numerical values of function U; two rows to also store values of previous time step 
double Usol[M+1];  // stores true solution 
double dt = T/N;
double dx = 1./M;
double dtdx = dt/(dx*dx);
float sendL, sendU; // variables used to send values between processes
float gather[J-2];
float temp[M+1];

MPI_Status status;
MPI_Comm comm;
comm = MPI_COMM_WORLD;
MPI_Init(NULL,NULL);
MPI_Comm_rank(comm, &rank);
MPI_Comm_size(comm, &size);

// prints out only once
if (rank==0) {
  cout<<"J = "<<J<<endl;
  cout<< "\ndx="<<dx<<", dt="<<dt<<", dt/dx²="<< dtdx<<endl;
}

// initialize numerical array with given conditions
U[0][0]=0, U[0][M]=0, U[1][0]=0, U[1][M]=0;
for(int m=1; m<M; ++m){
	U[0][m] = sin(2*PI*m*dx) + 2*sin(5*PI*m*dx) + 3*sin(20*PI*m*dx);

}

// use numerical scheme to obtain the future values of U on the M+1 space points
for(int i=1; i<=N; ++i){
	for (int m=1; m<J-1; ++m){
          U[1][m+((J-2)*rank)] = U[0][m+((J-2)*rank)] + dtdx * (U[0][m+((J-2)*rank)-1] - 2*U[0][m+((J-2)*rank)] + U[0][m+((J-2)*rank)+1]);
        }
        if (rank > 0) {
          // sends values down to the rank below
          sendL = U[1][1+((J-2)*rank)];
          MPI_Send(&sendL, 1, MPI_FLOAT, rank-1, 0, comm);
        }
        if (rank < nproc-1) {
          // receives values from above
          MPI_Recv(&sendL, 1, MPI_FLOAT, rank+1, 0, comm, &status);
          U[1][1+((J-2)*(rank+1))] = sendL;
          // sends values up to the rank above
          sendU = U[1][((J-2)*(rank+1))];
          MPI_Send(&sendU, 1, MPI_FLOAT, rank+1, 0, comm);
        }
        if (rank > 0) {
          // receives values from below
          MPI_Recv(&sendU, 1, MPI_FLOAT, rank-1, 0, comm, &status);
          U[1][((J-2)*(rank))] = sendU;
        }
        // update "old" value
        for(int m=0; m<=J-1; ++m){
          U[0][m+((J-2)*rank)] = U[1][m+((J-2)*rank)];
	}
        MPI_Barrier(comm);
}



// print out array entries of numerical solution next to true solution
for (int i=0; i<nproc; i++){
  if (rank==i){
    if (rank==0){
      cout << "\nTrue and numerical values at M="<<M<<" space points at time T="<<T<<":"<<endl;
      cout << "\nTrue values           Numerical solutions\n"<<endl;
      Usol[0] = exp(-4*PI*PI*T)*sin(2*PI*0*dx) + 2*exp(-25*PI*PI*T)*sin(5*PI*0*dx) + 3*exp(-400*PI*PI*T)*sin(20*PI*M*dx);
      cout << Usol[0] << "            " << U[1][0] << endl;
    }
    for(int m=1; m<J-1; ++m){
      Usol[m+((J-2)*rank)] = exp(-4*PI*PI*T)*sin(2*PI*(m+((J-2)*rank))*dx) + 2*exp(-25*PI*PI*T)*sin(5*PI*(m+((J-2)*rank))*dx) + 3*exp(-400*PI*PI*T)*sin(20*PI*M*dx);		
      cout << Usol[m+((J-2)*rank)] << "            " << U[1][m+((J-2)*rank)] << endl;
      // note that we did not really need to store the true solution in the array just to print out the values.
    }
    if (rank==nproc-1){
      Usol[M] = exp(-4*PI*PI*T)*sin(2*PI*M*dx) + 2*exp(-25*PI*PI*T)*sin(5*PI*M*dx) + 3*exp(-400*PI*PI*T)*sin(20*PI*M*dx);
      cout << Usol[M] << "             " << U[1][M] <<endl;
    }
  }
  // ensures that values are printed out in the correct order
  MPI_Barrier(comm);
}


return 0;

}
